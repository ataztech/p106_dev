<?php

echo trans('Standard::example.welcome');