<?php

namespace App\Modules\Demo\Models;

use Illuminate\Database\Eloquent\Model;

class Demo extends Model {

    protected $table = 'demos';
}
