<?php

namespace App\Modules\Demo\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Demo\Models\Demo;
use App\Modules\Price\Models\Price;
use Illuminate\Http\Request;
use Auth;
use Mail;
use Validator;
use DataTables;

class DemoController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function list()
    {
        return view('Demo::list');
    }

    public function data()
    {
        $demo = Demo::orderBy('id','desc')->get();

        return Datatables::of($demo)
            ->addColumn('alternative_contact_number', function($d) {
                if($d->alternative_contact_number == '')
                {
                    return 'N/A';
                }
            })
            ->make(true);
    }

    public function create(Request $request)
    {
        if($request->method()=="GET")
        {
            return view('Demo::create');
        }
        else
        {
            $validator = Validator::make($request->all(), [
                'name' => 'required',
                'contact_number' => 'required',
                'standard' => 'required',
                'date' => 'required',
                'time' => 'required',
                'address' => 'required',
            ]);
            if ($validator->fails()) {
                return redirect()->back()
                    ->withErrors($validator)
                    ->withInput();
            }
            $create_demo =  new Demo();
            $create_demo->student_name = $request->name;
            $create_demo->contact_number = $request->contact_number;
            $create_demo->alternative_contact_number = $request->alternative_contact_number;
            $create_demo->standard = $request->standard;
            $create_demo->date = $request->date;
            $create_demo->time = $request->time;
            $create_demo->address = $request->address;
            $create_demo->save();
            return redirect('telecaller/demo/list')->with('success','Demo Added Successfully!');
        }
    }

    public function update(Request $request,$id)
    {
        $demo = Demo::find($id);
        if($request->method()=="GET")
        {
            return view('Demo::update',['demo'=>$demo]);
        }
        else
        {
            $validator = Validator::make($request->all(), [
                'name' => 'required',
                'contact_number' => 'required',
                'standard' => 'required',
                'date' => 'required',
                'time' => 'required',
                'address' => 'required',
            ]);
            if ($validator->fails()) {
                return redirect()->back()
                    ->withErrors($validator)
                    ->withInput();
            }
            $demo->student_name = $request->name;
            $demo->contact_number = $request->contact_number;
            $demo->alternative_contact_number = $request->alternative_contact_number;
            $demo->standard = $request->standard;
            $demo->date = $request->date;
            $demo->time = $request->time;
            $demo->address = $request->address;
            $demo->save();
            return redirect('telecaller/demo/list')->with('success','Demo Updated Successfully!');
        }
    }

    public function delete($id)
    {
        Demo::find($id)->delete();
        return redirect('telecaller/demo/list')->with('success','Demo Delete Successfully!');
    }
}
