<?php

namespace App\Modules\Payment\Models;


use Auth;
use Illuminate\Database\Eloquent\Model;

class PaymentDetail extends Model
{

    protected $table = 'payment_details';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */


    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */

}
